app.component('posicao', {
  bindings: {
    acao: '@',         // Pai ➜ Filho (valor literal)
    funcao: '<',
    edit: '<',        // recebe dados do pai (objeto ou boolean)
    tipo: '<',        // inventario | conferencia (vindo da página)
    idUser: '<',      // recebe um valor (ID do usuário)
    onFechar: '&'    // callback (pai define o que acontece quando algo retorna)
  },

  controller: function (uteisService, $http, $timeout, $scope) {
    const $ctrl = this

    $ctrl._editPosicao = {};
    $ctrl._regConta = {};
    $ctrl._guiaDestino = true;
    $ctrl._analisePosicao = {
      total: 0,
      alertas: [],
      statusGeral: 'aberta',
      statusCor: 'primary',
      ehConferencia: false
    };

    $ctrl._regAddItem = {
      id_ref: 'item',
      id_item: '',
      id_categoria: '',
      quantidade: 1
    };

    $ctrl.options = {
      headers: { 'Content-Type': 'application/json' }
    };

    $ctrl.$onInit = function () {
      $ctrl._regConta = uteisService.getCookie('_conta');
      $ctrl._regConta = uteisService.normalizarConta($ctrl._regConta);

      $scope.$watchCollection(function () {
        var itens = ($ctrl._editPosicao && $ctrl._editPosicao.itens) || [];
        return Array.isArray(itens) ? itens : [];
      }, function () {
        $ctrl.atualizarAnalisePosicao();
      });

      $scope.$watch(function () {
        var p = $ctrl._editPosicao || {};
        return (p.tipo || '') + '|' + (p.status || '') + '|' + (p.total_itens || '') + '|' + (p.total_concluido || '');
      }, function () {
        $ctrl.atualizarAnalisePosicao();
      });
    };

    $ctrl.$onChanges = function (changes) {

      if ($ctrl.funcao == 'add') {
        $ctrl.onEditar(undefined)
      } else if ($ctrl.funcao == 'edit') {
        $ctrl.onEditar($ctrl.edit)
      };

    };

    $ctrl.onEditar = async function (reg) {

      await $ctrl.onCarregaNiveis('01');
      await $ctrl.onCarregaNiveisDestino('01')
      await $ctrl.onCarregaCategorias();
      await $ctrl.onCarregaCategoriasTipos();
      // Itens: não carrega lista completa — só os da ordem (ensureItensDaPosicao)

      const tabTrigger = document.querySelector('#categorias-a-tab');
      const tab = new bootstrap.Tab(tabTrigger);
      tab.show();

      if (reg == undefined) {

        $ctrl._editPosicao = {

          _id: uteisService.onGetID(),
          id_conta: $ctrl._regConta._id,
          ativo: '1',
          id_doc: '',
          descricao: '',
          observacao: '',
          tipo: $ctrl.tipo || 'inventario',

          icone: '',
          _icone: '../assets/images/icon_cadastro.fw.png',

          partida_data: '',
          tolerancia: 30,

          status: 'aberta',
          status_data: '',

          id_nivel_loc1: '',
          id_nivel_loc2: '',
          id_nivel_loc3: '',
          id_nivel_loc4: '',

          itens: [],

          previsao_chegada_data: '',
          previsao_chegada_tolerancia: 30,

          id_nivel_loc1_destino: '',
          id_nivel_loc2_destino: '',
          id_nivel_loc3_destino: '',
          id_nivel_loc4_destino: '',
        };

      } else {

        $ctrl._editPosicao = reg;
        $ctrl._editPosicao.ativo = "" + $ctrl._editPosicao.ativo;
        $ctrl._editPosicao._partida_data = $ctrl._editPosicao.partida_data;
        // Cópia bruta da previsão cadastrada (para exibição na lista quando ainda não há chegada real).

        // datetime-local no Angular 1 usa Date no ng-model; string ISO costuma não renderizar.
        // Zerar ms evita exibir milissegundos (ex.: ",949" em pt-BR).
        var mp = moment($ctrl._editPosicao.partida_data);
        if (mp.isValid()) {
          $ctrl._editPosicao.partida_data = mp.add(0, 'hours').millisecond(0).toDate();
        }

        var mprev = moment($ctrl._editPosicao.previsao_chegada_data);
        if (mprev.isValid()) {
          $ctrl._editPosicao.previsao_chegada_data = mprev.add(0, 'hours').millisecond(0).toDate();
        }


        $ctrl._editPosicao['_foto'] = '../assets/images/icon_cadastro.fw.png'
        if ($ctrl._editPosicao.foto) {
          $ctrl._editPosicao._foto = uteisService.apiUrl_() + '/image/' + $ctrl._editPosicao.foto
        };

        if ($ctrl._editPosicao.id_nivel_loc1) {

          await $ctrl.onCarregaNiveis('02')

          $timeout(async () => {
            if ($ctrl._editPosicao.id_nivel_loc2) {
              await $ctrl.onCarregaNiveis('03')

              $timeout(async () => {
                if ($ctrl._editPosicao.id_nivel_loc3) {
                  await $ctrl.onCarregaNiveis('04')
                };
              }, 200)
            }
          }, 200)
        }

        if ($ctrl._editPosicao.id_nivel_loc1_destino) {

          await $ctrl.onCarregaNiveisDestino('02')

          $timeout(async () => {
            if ($ctrl._editPosicao.id_nivel_loc2_destino) {
              await $ctrl.onCarregaNiveisDestino('03')

              $timeout(async () => {
                if ($ctrl._editPosicao.id_nivel_loc3_destino) {
                  await $ctrl.onCarregaNiveisDestino('04')
                };
              }, 200)
            }
          }, 200)
        }



      };

      await $ctrl.ensureItensDaPosicao(($ctrl._editPosicao && $ctrl._editPosicao.itens) || []);
      $ctrl.atualizarAnalisePosicao();

    };

    $ctrl.onCarregaCategorias = async function () {

      let _url = '/_bd?c=categoria&id_conta=' + $ctrl._regConta._id
      _url += '&sort=descricao'

      await uteisService.getBase(_url)
        .then((res) => {

          $timeout(() => {
            $ctrl._listCategorias = res
          }, 10);

        })
        .catch((error) => {
          uteisService.onToast('Algo deu errado, tente novamente por favor.', 'error', 2000, 'top-end');
        });
    };

    $ctrl.onCarregaCategoriasTipos = async function () {

      let _url = '/_bd?c=categoria_item&id_conta=' + $ctrl._regConta._id
      _url += '&sort=descricao'

      await uteisService.getBase(_url)
        .then((res) => {

          $timeout(() => {
            $ctrl._listCategoriasTipos = res
          }, 10);

        })
        .catch((error) => {
          uteisService.onToast('Algo deu errado, tente novamente por favor.', 'error', 2000, 'top-end');
        });
    };

    $ctrl._mapItensPorId = {};
    $ctrl._buscandoItemId = {};

    /** Busca item por _id (1 request). Usado na conferência sem carregar a lista inteira. */
    $ctrl.carregarItemPorId = async function (idItem) {
      if (!idItem) return null;
      if ($ctrl._mapItensPorId[idItem]) return $ctrl._mapItensPorId[idItem];
      if ($ctrl._buscandoItemId[idItem]) return $ctrl._buscandoItemId[idItem];

      const idConta = ($ctrl._regConta && $ctrl._regConta._id) || '';
      const url = '/_bd?c=item&id_conta=' + encodeURIComponent(idConta)
        + '&_id=' + encodeURIComponent(idItem)
        + '&pop=id_categoria&pop=id_categoria_reg1&limit=1';

      const promessa = (async () => {
        try {
          const res = await uteisService.getBase(url).catch(() => []);
          const item = (Array.isArray(res) && res[0]) ? res[0] : null;
          if (item) {
            $ctrl._mapItensPorId[item._id] = item;
            // Mantém _listItens sincronizado para add/select (só o necessário)
            $ctrl._listItens = $ctrl._listItens || [];
            if (!$ctrl._listItens.find((i) => i._id == item._id)) {
              $ctrl._listItens.push(item);
            }
          }
          return item;
        } finally {
          delete $ctrl._buscandoItemId[idItem];
        }
      })();

      $ctrl._buscandoItemId[idItem] = promessa;
      return promessa;
    };

    /** Carrega só os itens referenciados na ordem (batch por ids). */
    $ctrl.ensureItensDaPosicao = async function (itens) {
      const ids = [...new Set((itens || []).map((it) => it && it.id_item).filter(Boolean))];
      const faltando = ids.filter((id) => !$ctrl._mapItensPorId[id]);
      if (!faltando.length) return;

      const idConta = ($ctrl._regConta && $ctrl._regConta._id) || '';
      const url = '/_bd?c=item&id_conta=' + encodeURIComponent(idConta)
        + '&_id*in=' + encodeURIComponent(JSON.stringify(faltando))
        + '&pop=id_categoria&pop=id_categoria_reg1&limit=' + faltando.length;

      try {
        const res = await uteisService.getBase(url).catch(() => []);
        (Array.isArray(res) ? res : []).forEach((item) => {
          if (!item || !item._id) return;
          $ctrl._mapItensPorId[item._id] = item;
          $ctrl._listItens = $ctrl._listItens || [];
          if (!$ctrl._listItens.find((i) => i._id == item._id)) {
            $ctrl._listItens.push(item);
          }
        });
        // Fallback individual se *in não retornou todos
        const aindaFaltando = faltando.filter((id) => !$ctrl._mapItensPorId[id]);
        if (aindaFaltando.length) {
          await Promise.all(aindaFaltando.map((id) => $ctrl.carregarItemPorId(id)));
        }
        $timeout(() => { }, 0);
      } catch (e) {
        await Promise.all(faltando.map((id) => $ctrl.carregarItemPorId(id)));
      }
    };

    // Não carrega mais a lista completa de itens (limite 3500). Só sob demanda.
    $ctrl.onCarregaItens = async function () {
      $ctrl._listItens = $ctrl._listItens || [];
      $ctrl._mapItensPorId = $ctrl._mapItensPorId || {};
    };

    $ctrl.onCarregaItensInventario = async function () {
      if ($ctrl._editPosicao.tipo !== 'inventario') return;
      if (!$ctrl._editPosicao.id_nivel_loc1) {
        $ctrl._editPosicao.itens = [];
        return;
      }

      let _url = '/_bd?c=item&id_conta=' + $ctrl._regConta._id;
      _url += '&pop=id_categoria';
      _url += '&id_nivel_loc1=' + encodeURIComponent($ctrl._editPosicao.id_nivel_loc1);

      if ($ctrl._editPosicao.id_nivel_loc2) {
        _url += '&id_nivel_loc2=' + encodeURIComponent($ctrl._editPosicao.id_nivel_loc2);
      }
      if ($ctrl._editPosicao.id_nivel_loc3) {
        _url += '&id_nivel_loc3=' + encodeURIComponent($ctrl._editPosicao.id_nivel_loc3);
      }
      if ($ctrl._editPosicao.id_nivel_loc4) {
        _url += '&id_nivel_loc4=' + encodeURIComponent($ctrl._editPosicao.id_nivel_loc4);
      }

      try {
        const res = await uteisService.getBase(_url);
        const itensEncontrados = Array.isArray(res) ? res : [];
        const existentes = {};

        ($ctrl._editPosicao.itens || []).forEach((item) => {
          if (item && item.id_item) existentes[item.id_item] = item;
        });

        $ctrl._editPosicao.itens = itensEncontrados.map((item) => {
          if (existentes[item._id]) return existentes[item._id];
          return montarItemPosicao(item);
        });

        $timeout(() => {
          itensEncontrados.forEach((it) => {
            if (it && it._id) $ctrl._mapItensPorId[it._id] = it;
          });
          $ctrl._listItens = itensEncontrados;
        }, 10);
      } catch (error) {
        uteisService.onToast('Não foi possível carregar os itens do endereço.', 'error', 2000, 'top-end');
      }
    };

    const getIdRef = (obj) => (obj && obj._id ? obj._id : (obj || ''));

    const montarItemPosicao = function (item) {
      return {
        _id: uteisService.onGetID(),
        id_item: item._id,
        id_categoria: '',

        tag: item.tag,
        ean: '',
        rssi: '',

        quantidade: 1,
        status: 'pendente',
        status_data: '',
        id_gatweway: '',
        id_colaborador: '',

        inf_compl_1: item.inf_compl1,
        inf_compl_2: item.inf_compl2,
        inf_compl_3: item.inf_compl3,
        inf_compl_4: item.inf_compl4,
        inf_compl_5: item.inf_compl5,

        status_destino: '',
        status_destino_data: '',
      };
    };

    const limparNiveisFilhos = function (nivel) {
      if (nivel === '02') {
        $ctrl._editPosicao.id_nivel_loc2 = '';
        $ctrl._editPosicao.id_nivel_loc3 = '';
        $ctrl._editPosicao.id_nivel_loc4 = '';
      } else if (nivel === '03') {
        $ctrl._editPosicao.id_nivel_loc3 = '';
        $ctrl._editPosicao.id_nivel_loc4 = '';
      } else if (nivel === '04') {
        $ctrl._editPosicao.id_nivel_loc4 = '';
      }
    };

    const limparNiveisFilhosDestino = function (nivel) {
      if (nivel === '02') {
        $ctrl._editPosicao.id_nivel_loc2_destino = '';
        $ctrl._editPosicao.id_nivel_loc3_destino = '';
        $ctrl._editPosicao.id_nivel_loc4_destino = '';
      } else if (nivel === '03') {
        $ctrl._editPosicao.id_nivel_loc3_destino = '';
        $ctrl._editPosicao.id_nivel_loc4_destino = '';
      } else if (nivel === '04') {
        $ctrl._editPosicao.id_nivel_loc4_destino = '';
      }
    };

    $ctrl.onNivelLocChange = async function (nivel) {
      limparNiveisFilhos(nivel);
      await $ctrl.onCarregaNiveis(nivel);
    };

    $ctrl.onNivelLocDestinoChange = async function (nivel) {
      limparNiveisFilhosDestino(nivel);
      await $ctrl.onCarregaNiveisDestino(nivel);
    };

    $ctrl.onCarregaNiveis = async function (nivel) {

      let id_nivel = null;
      if (nivel == '02') {
        id_nivel = $ctrl._editPosicao.id_nivel_loc1
      } else if (nivel == '03') {
        id_nivel = $ctrl._editPosicao.id_nivel_loc2
      } else if (nivel == '04') {
        id_nivel = $ctrl._editPosicao.id_nivel_loc3
      }

      let _url = '/_bd?c=localizacao&id_conta=' + $ctrl._regConta._id + '&id_nivel=' + id_nivel
      _url += '&sort=descricao'

      await uteisService.getBase(_url)
        .then(async (res) => {

          $timeout(async () => {
            if (nivel == '01') {
              $ctrl._listNivel1 = res
              $ctrl._listNivel2 = []
              $ctrl._listNivel3 = [];
              $ctrl._listNivel4 = [];
            } else if (nivel == '02') {
              $ctrl._listNivel2 = res
              $ctrl._listNivel3 = [];
              $ctrl._listNivel4 = [];
            } else if (nivel == '03') {
              $ctrl._listNivel3 = res
              $ctrl._listNivel4 = [];

            } else if (nivel == '04') {
              $ctrl._listNivel4 = res
            };

            if ($ctrl._editPosicao.tipo === 'inventario' && nivel !== '01') {
              await $ctrl.onCarregaItensInventario();
            }
          }, 900)
        })
        .catch((error) => {
          uteisService.onToast('Algo deu errado, tente novamente por favor.', 'error', 2000, 'top-end');
        });
    };

    $ctrl.onCarregaNiveisDestino = async function (nivel) {

      let id_nivel = null;
      if (nivel == '02') {
        id_nivel = $ctrl._editPosicao.id_nivel_loc1_destino
      } else if (nivel == '03') {
        id_nivel = $ctrl._editPosicao.id_nivel_loc2_destino
      } else if (nivel == '04') {
        id_nivel = $ctrl._editPosicao.id_nivel_loc3_destino
      }

      let _url = '/_bd?c=localizacao&id_conta=' + $ctrl._regConta._id + '&id_nivel=' + id_nivel
      _url += '&sort=descricao'

      await uteisService.getBase(_url)
        .then((res) => {

          $timeout(() => {
            if (nivel == '01') {
              $ctrl._listNivel1Destino = res
              $ctrl._listNivel2Destino = []
              $ctrl._listNivel3Destino = [];
              $ctrl._listNivel4Destino = [];
            } else if (nivel == '02') {
              $ctrl._listNivel2Destino = res
              $ctrl._listNivel3Destino = [];
              $ctrl._listNivel4Destino = [];
            } else if (nivel == '03') {
              $ctrl._listNivel3Destino = res
              $ctrl._listNivel4Destino = [];

            } else if (nivel == '04') {
              $ctrl._listNivel4Destino = res
            };
          }, 900)
        })
        .catch((error) => {
          uteisService.onToast('Algo deu errado, tente novamente por favor.', 'error', 2000, 'top-end');
        });
    };

    $ctrl.onDefineLocal = async function (_setar) {

      if (_setar) {
        let item = $ctrl._mapItensPorId[$ctrl._regAddItem.id_item]
          || ($ctrl._listItens || []).find((i) => i._id == $ctrl._regAddItem.id_item);
        if (!item) {
          item = await $ctrl.carregarItemPorId($ctrl._regAddItem.id_item);
        }
        if (!item) return;

        $ctrl._editPosicao.id_nivel_loc1 = item.id_nivel_loc1
        $ctrl._editPosicao.id_nivel_loc2 = item.id_nivel_loc2
        $ctrl._editPosicao.id_nivel_loc3 = item.id_nivel_loc3
        $ctrl._editPosicao.id_nivel_loc4 = item.id_nivel_loc4

        if ($ctrl._editPosicao.id_nivel_loc1) {

          await $ctrl.onCarregaNiveis('02')

          $timeout(async () => {
            if ($ctrl._editPosicao.id_nivel_loc2) {
              await $ctrl.onCarregaNiveis('03')

              $timeout(async () => {
                if ($ctrl._editPosicao.id_nivel_loc3) {
                  await $ctrl.onCarregaNiveis('04')
                };
              }, 200)
            }
          }, 200)
        }

      } else {
        $ctrl._editPosicao.id_nivel_loc1 = ''
        $ctrl._editPosicao.id_nivel_loc2 = ''
        $ctrl._editPosicao.id_nivel_loc3 = ''
        $ctrl._editPosicao.id_nivel_loc4 = ''
      }

    }

    $ctrl.onAddItem = async function () {

      if ($ctrl._regAddItem.id_ref == 'item') {

        let iFind = $ctrl._editPosicao.itens.findIndex((item) => item.id_item == $ctrl._regAddItem.id_item)
        let itemCad = $ctrl._mapItensPorId[$ctrl._regAddItem.id_item]
          || ($ctrl._listItens || []).find((i) => i._id == $ctrl._regAddItem.id_item);
        if (!itemCad) {
          itemCad = await $ctrl.carregarItemPorId($ctrl._regAddItem.id_item);
        }
        if (!itemCad) {
          uteisService.onToast('Item não encontrado.', 'warning', 2000, 'top-end');
          return;
        }
   
        if (iFind == -1) {
          $ctrl._editPosicao.itens.push({
            _id: uteisService.onGetID(),
            id_item: $ctrl._regAddItem.id_item,
            id_categoria: '',

            tag: itemCad.tag,
            ean: '',
            rssi: '',

            quantidade: $ctrl._regAddItem.quantidade || 1,
            status: 'pendente',
            status_data: '',
            id_gatweway: '',
            id_colaborador: '',

            inf_compl_1: itemCad.inf_compl1,
            inf_compl_2: itemCad.inf_compl2,
            inf_compl_3: itemCad.inf_compl3,
            inf_compl_4: itemCad.inf_compl4,
            inf_compl_5: itemCad.inf_compl5,

            status_destino: '',
            status_destino_data: '',
          })
        } else {
          $ctrl._editPosicao.itens[iFind].quantidade = $ctrl._regAddItem.quantidade
        }

      } else {


        let iFind = $ctrl._editPosicao.itens.findIndex((item) => item.id_categoria == $ctrl._regAddItem.id_categoria)
        if (iFind == -1) {
          $ctrl._editPosicao.itens.push({
            _id: uteisService.onGetID(),
            id_item: '',
            id_categoria: $ctrl._regAddItem.id_categoria,
            quantidade: $ctrl._regAddItem.quantidade,
            status: 'pendente',
            status_data: '',
            id_gatweway: '',
            id_colaborador: '',
          })
        } else {
          $ctrl._editPosicao.itens[iFind].quantidade = $ctrl._regAddItem.quantidade
        }

      }


    };

    $ctrl.onGetFoto = function () {

      document.getElementById('imgLogo').click();
      document.getElementById('imgLogo').onchange = function () {

        $ctrl._editPosicao._foto = "assets/images/carregando_icon.gif";

        const file = this.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = function (e) {

            $http.post(uteisService.apiUrl_() + '/image/save', [{ foto: e.target.result }], $ctrl.options)
              .then(function (res) {
                $timeout(() => {
                  $ctrl._editPosicao._foto = e.target.result;
                  $ctrl._editPosicao.foto = res.data[0].id_foto
                }, 2000)

              }, function (error) { });

          };
          reader.readAsDataURL(file);
        }

      };
    };


    $ctrl.onSalvar = function () {


      if ($ctrl._editPosicao.id_doc == '') {
        uteisService.onToast('Informe um iD para identificar o Documento.', 'warning', 3000, 'top-end');
        const tabTrigger = document.querySelector('#categorias-a-tab');
        const tab = new bootstrap.Tab(tabTrigger);
        tab.show();
        return;
      };

      if ($ctrl._editPosicao.partida_data == '') {
        uteisService.onToast('Informe a data de partida.', 'warning', 3000, 'top-end');
        const tabTrigger = document.querySelector('#categorias-a-tab');
        const tab = new bootstrap.Tab(tabTrigger);
        tab.show();
        return;
      };

      if ($ctrl._editPosicao.itens.length == 0) {
        uteisService.onToast('Selecione os itens que serão Movimentados.', 'warning', 3000, 'top-end');
        const tabTrigger = document.querySelector('#categorias-b-tab');
        const tab = new bootstrap.Tab(tabTrigger);
        tab.show();
        return;
      };

      if ($ctrl._editPosicao.previsao_chegada_data == '' && $ctrl._editPosicao.tipo == 'conferencia') {
        uteisService.onToast('Informe a data de previsão de chegada.', 'warning', 3000, 'top-end');
        const tabTrigger = document.querySelector('#categorias-c-tab');
        const tab = new bootstrap.Tab(tabTrigger);
        tab.show();
        return;
      };


      if ($ctrl._editPosicao.id_nivel_loc1_destino == '' && $ctrl._editPosicao.tipo == 'conferencia') {
        uteisService.onToast('Selecione o Local de destino.', 'warning', 3000, 'top-end');
        const tabTrigger = document.querySelector('#categorias-c-tab');
        const tab = new bootstrap.Tab(tabTrigger);
        tab.show();
        return;
      };

      // Normaliza totais / status (total_itens previsto × itens concluídos)
      if (uteisService.normalizarTotaisPosicao) {
        var totaisSave = uteisService.normalizarTotaisPosicao($ctrl._editPosicao);
        $ctrl._editPosicao.total_itens = totaisSave.total_itens;
        $ctrl._editPosicao.total_concluido = totaisSave.total_concluido;
        var stAtual = String($ctrl._editPosicao.status || '').toLowerCase();
        if (!stAtual || stAtual === 'pendente' || stAtual === 'parcial' || stAtual === 'concluido') {
          $ctrl._editPosicao.status = totaisSave.status;
          $ctrl._editPosicao.status_data = new Date();
        }
      }

      uteisService.patchBase('/posicao', $ctrl._editPosicao)
        .then((res) => {
          uteisService.onToast('Registrado!', 'success', 3000, 'top-end');
          $ctrl.onFechar();
        })

    };

    $ctrl.onExcluir = function () {

      uteisService.onQuestion("Atenção!", "Deseja realmente excluir esse Registro?")
        .then(async (res) => {
          if (res) {
            uteisService.delBase('posicao/_id/' + $ctrl._editPosicao._id)
            uteisService.onToast('Registrado excuido!', 'success', 3000, 'top-end');
            $ctrl.fechar();
          }
        })
    }


    $ctrl.descricaoNivelLoc = function (nivel) {
      const id = $ctrl._editPosicao['id_nivel_loc' + nivel];
      if (!id) return 'Não definido';

      const lista = $ctrl['_listNivel' + nivel];
      if (!Array.isArray(lista)) return 'Não definido';

      const found = lista.find((item) => item && item._id === id);
      if (!found) return 'Não definido';

      return found.descricao || found.tag || id;
    };

    $ctrl.idItemDescricao = function (_idItem, _idCategoria, desc) {

      if (_idItem) {
        const item = $ctrl._mapItensPorId[_idItem]
          || ($ctrl._listItens || []).find((i) => i._id == _idItem)
          || null;

        if (item) {
          if (desc) {
            const cat = item.id_categoria;
            return (cat && cat.descricao) || item.descricao || 'SKU';
          }
          return item.tag || _idItem;
        }

        // Ainda não no cache: dispara carga individual (ensureItensDaPosicao no open cobre o lote)
        if (!$ctrl._buscandoItemId[_idItem]) {
          $ctrl.carregarItemPorId(_idItem).then(() => $timeout(() => { }, 0));
        }
        return '…';
      }

      if (_idCategoria) {
        let iFind = ($ctrl._listCategorias || []).findIndex((item) => item._id == _idCategoria)
        if (iFind != -1) {
          if (desc) {
            return $ctrl._listCategorias[iFind].descricao;
          }
          return $ctrl._listCategorias[iFind].ean
        }
        return 'Item N/A'
      }

      return 'SKU N/A';
    };

    $ctrl.idItemTipoDescricao = function (_idItem) {
      if (!_idItem) return 'Tipo de Item N/A';
      const item = $ctrl._mapItensPorId[_idItem]
        || ($ctrl._listItens || []).find((i) => i._id == _idItem)
        || null;
      if (!item) {
        if (!$ctrl._buscandoItemId[_idItem]) {
          $ctrl.carregarItemPorId(_idItem).then(() => $timeout(() => { }, 0));
        }
        return '…';
      }
      const idTipo = item.id_categoria_reg1 && (item.id_categoria_reg1._id || item.id_categoria_reg1);
      let iFindTipo = ($ctrl._listCategoriasTipos || []).findIndex((t) => t._id == idTipo)
      if (iFindTipo != -1) {
        return $ctrl._listCategoriasTipos[iFindTipo].descricao
      }
      return 'Tipo de Item N/A'
    }

    $ctrl.formataDataHora = function (data) {
      if (!data) return '';
      var date = moment(data, [
        'YYYY-MM-DD HH:mm:ss',
        'YYYY-MM-DDTHH:mm:ss',
        'YYYY-MM-DDTHH:mm:ss.SSS',
        moment.ISO_8601
      ], true);
      if (!date.isValid()) date = moment(data);
      if (!date.isValid()) return '';
      return date.add(0, 'hours').format('DDMMM HH[h]mm');
    };

    /** Enquanto nenhum item tiver data de chegada ao destino, a UI usa a previsão cadastrada. */
    $ctrl.semStatusDestinoDataNosItens = function () {
      var itens = ($ctrl._editPosicao && $ctrl._editPosicao.itens) || [];
      for (var i = 0; i < itens.length; i++) {
        if (itens[i] && itens[i].status_destino_data) return false;
      }
      return true;
    };

    const parseDataPosicao = function (data) {
      if (!data) return null;
      var date = moment(data, [
        'YYYY-MM-DD HH:mm:ss',
        'YYYY-MM-DDTHH:mm:ss',
        'YYYY-MM-DDTHH:mm:ss.SSS',
        moment.ISO_8601
      ], true);
      if (!date.isValid()) date = moment(data);
      return date.isValid() ? date : null;
    };

    const formatarDuracaoLeitura = function (ms) {
      if (ms == null || ms < 0) return '—';
      var dur = moment.duration(ms);
      var h = Math.floor(dur.asHours());
      var m = dur.minutes();
      var s = dur.seconds();
      if (h > 0) return h + 'h ' + m + 'min';
      if (m > 0) return m + ' min ' + s + 's';
      return s + 's';
    };

    $ctrl.atualizarAnalisePosicao = function () {
      var itens = ($ctrl._editPosicao && $ctrl._editPosicao.itens) || [];
      if (!Array.isArray(itens)) itens = [];

      // Totais previstos (total_itens) × concluídos — regra única do sistema
      var totais = uteisService.normalizarTotaisPosicao
        ? uteisService.normalizarTotaisPosicao($ctrl._editPosicao || { itens: itens })
        : { total_itens: itens.length, total_concluido: 0, status: 'pendente' };

      var total = totais.total_itens || 0;
      var concluido = totais.total_concluido || 0;
      var vinculados = itens.length;
      var aguardandoImputacao = Math.max(0, total - vinculados);

      var pendenteArr = 0;
      var excedente = 0;
      var naoEncontrado = 0;
      var destinoConcluido = 0;
      var destinoPendente = 0;
      var quantidadeTotal = 0;
      var datasLeitura = [];

      itens.forEach(function (item) {
        if (!item) return;
        quantidadeTotal += Number(item.quantidade) || 1;

        var st = String(item.status || 'pendente').toLowerCase();
        if (st === 'concluido') { /* contado em totais */ }
        else if (st === 'excedente') excedente += 1;
        else if (st === 'nao_encontrado') naoEncontrado += 1;
        else pendenteArr += 1;

        var std = String(item.status_destino || 'pendente').toLowerCase();
        if (std === 'concluido') destinoConcluido += 1;
        else destinoPendente += 1;

        var dt = parseDataPosicao(item.status_data);
        if (dt) datasLeitura.push(dt);
      });

      // Pendentes do previsto = ainda não lidos (lista + slots não imputados)
      var pendente = Math.max(0, total - concluido);

      var pct = total > 0 ? Math.round((concluido / total) * 100) : 0;
      var pctDestino = vinculados > 0 ? Math.round((destinoConcluido / vinculados) * 100) : 0;

      var primeiraLeitura = null;
      var ultimaLeitura = null;
      var tempoLeitura = '—';

      if (datasLeitura.length >= 1) {
        datasLeitura.sort(function (a, b) { return a.valueOf() - b.valueOf(); });
        primeiraLeitura = datasLeitura[0];
        ultimaLeitura = datasLeitura[datasLeitura.length - 1];
        if (datasLeitura.length >= 2) {
          tempoLeitura = formatarDuracaoLeitura(ultimaLeitura.diff(primeiraLeitura));
        } else {
          tempoLeitura = '0s';
        }
      }

      var alertas = [];
      if (vinculados === 0 && total === 0) {
        alertas.push({ tipo: 'secondary', icon: 'bi-inbox', msg: 'Nenhum item vinculado a este registro ainda.' });
      }
      if (aguardandoImputacao > 0) {
        alertas.push({
          tipo: 'info',
          icon: 'bi-cloud-download',
          msg: aguardandoImputacao + ' item(ns) previstos ainda não imputados na ordem (' + vinculados + '/' + total + ').'
        });
      }
      if (pendenteArr > 0) {
        alertas.push({ tipo: 'warning', icon: 'bi-hourglass-split', msg: pendenteArr + ' item(ns) aguardando leitura na origem.' });
      }
      if (naoEncontrado > 0) {
        alertas.push({ tipo: 'danger', icon: 'bi-exclamation-triangle', msg: naoEncontrado + ' item(ns) não encontrado(s).' });
      }
      if (excedente > 0) {
        alertas.push({ tipo: 'info', icon: 'bi-plus-circle', msg: excedente + ' leitura(s) excedente(s) registrada(s).' });
      }

      var ehConferencia = $ctrl._editPosicao && $ctrl._editPosicao.tipo === 'conferencia';
      if (ehConferencia && vinculados > 0) {
        if (destinoPendente > 0) {
          alertas.push({
            tipo: 'warning',
            icon: 'bi-geo-alt',
            msg: destinoPendente + ' item(ns) sem confirmação de leitura no destino.'
          });
        }
        if (concluido >= total && total > 0 && destinoPendente > 0) {
          alertas.push({
            tipo: 'danger',
            icon: 'bi-signpost-split',
            msg: 'Origem concluída — aguardando leituras no destino.'
          });
        }
        if (destinoConcluido === vinculados && vinculados > 0 && concluido >= total && total > 0) {
          alertas.push({
            tipo: 'success',
            icon: 'bi-check-circle',
            msg: 'Todos os itens confirmados no destino.'
          });
        }
      }

      if (pct === 100 && total > 0 && !ehConferencia) {
        alertas.push({ tipo: 'success', icon: 'bi-check-all', msg: 'Inventário concluído — 100% dos itens lidos.' });
      }

      // Status exibido: totais (exceto aberta/partida manuais)
      var stDoc = String(($ctrl._editPosicao && $ctrl._editPosicao.status) || '').toLowerCase();
      var statusGeral = (stDoc === 'aberta' || stDoc === 'partida') ? stDoc : (totais.status || stDoc || 'aberta');
      var statusCor = 'secondary';
      if (statusGeral === 'concluido') statusCor = 'success';
      else if (statusGeral === 'parcial') statusCor = 'warning';
      else if (statusGeral === 'partida') statusCor = 'info';
      else if (statusGeral === 'aberta' || statusGeral === 'pendente') statusCor = 'primary';

      $ctrl._analisePosicao = {
        total: total,
        vinculados: vinculados,
        aguardandoImputacao: aguardandoImputacao,
        quantidadeTotal: quantidadeTotal,
        concluido: concluido,
        pendente: pendente,
        pendenteArr: pendenteArr,
        excedente: excedente,
        naoEncontrado: naoEncontrado,
        pct: pct,
        pctDestino: pctDestino,
        destinoConcluido: destinoConcluido,
        destinoPendente: destinoPendente,
        tempoLeitura: tempoLeitura,
        primeiraLeituraFmt: primeiraLeitura ? primeiraLeitura.format('DD/MMM HH:mm:ss') : '—',
        ultimaLeituraFmt: ultimaLeitura ? ultimaLeitura.format('DD/MMM HH:mm:ss') : '—',
        temLeituras: datasLeitura.length > 0,
        alertas: alertas,
        statusGeral: statusGeral,
        statusCor: statusCor,
        ehConferencia: ehConferencia,
        lidosLabel: concluido + ' / ' + total,
        segmentos: [
          { label: 'Concluído', valor: concluido, cor: 'success' },
          { label: 'Pendente', valor: pendenteArr, cor: 'danger' },
          { label: 'A imputar', valor: aguardandoImputacao, cor: 'info' },
          { label: 'Excedente', valor: excedente, cor: 'purple' },
          { label: 'Não enc.', valor: naoEncontrado, cor: 'warning' }
        ].filter(function (s) { return s.valor > 0; })
      };
    };

    $ctrl.fechar = function () {
      // dispara o callback do pai

      $timeout(() => {
        $ctrl._listNivel1 = [];
        $ctrl._listNivel2 = [];
        $ctrl._listNivel3 = [];
        $ctrl._listNivel4 = [];
        $ctrl._listNivel1Destino = []
        $ctrl._listNivel2Destino = []
        $ctrl._listNivel3Destino = [];
        $ctrl._listNivel4Destino = [];
      }, 100);

      $ctrl.onFechar();
    };

  },
  templateUrl: 'components/posicao/posicao.html'
});