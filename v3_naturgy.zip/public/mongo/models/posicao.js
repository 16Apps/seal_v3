const mongoose = require('mongoose');
const shortid = require('shortid');

const PosicaoSchema = new mongoose.Schema({
    _id: { type: String, default: shortid.generate },
    id_conta: { type: String, ref: 'Conta' },
    id_colaborador: { type: String, ref: 'Colaborador' },

    ativo: { type: String },
    id_doc: { type: String },
    descricao: { type: String },
    icone: { type: String },
    tipo: { type: String, enum: ['conferencia', 'inventario'], default: 'conferencia' },

    partida_data: { type: Date },
    tolerancia: { type: Number },

    previsao_chegada_data: { type: Date },
    previsao_chegada_tolerancia: { type: Number },

    status: { 
        type: String,
        enum: ['pendente','aberta','parcial','concluido','partida'],
        default: 'pendente'
      },
    status_data: { type: Date },

    /** Total previsto de itens (informado pelo cliente). Fallback: itens.length */
    total_itens: { type: Number, default: null },
    /** Cache: qtd de itens com status concluido */
    total_concluido: { type: Number, default: null },

    id_nivel_loc1: { type: String, ref: 'Localizacao' },
    id_nivel_loc2: { type: String, ref: 'Localizacao' },
    id_nivel_loc3: { type: String, ref: 'Localizacao' },
    id_nivel_loc4: { type: String, ref: 'Localizacao' },

    itens: [{
        _id: { type: String, default: shortid.generate },
        id_item: { type: String, ref: 'Item' },
        id_categoria: { type: String, ref: 'Categoria' },

        tag: { type: String },
        ean: { type: String },
        rssi: { type: String },

        inf_compl_1: { type: String },
        inf_compl_2: { type: String },
        inf_compl_3: { type: String },
        inf_compl_4: { type: String },
        inf_compl_5: { type: String },

        quantidade: { type: Number },
        status: { type: String, enum: ['pendente',  'concluido', 'excedente', 'nao_encontrado'	], default: 'pendente' },
        status_data: { type: Date },
        id_gatweway: { type: String, ref: 'Gateway' },
        id_colaborador: { type: String, ref: 'Colaborador' },

        status_destino: { type: String, enum: ['pendente',  'concluido'	], default: 'pendente' },
        status_destino_data: { type: Date },

        retorno_data: { type: Date },
    }],

    id_nivel_loc1_destino: { type: String, ref: 'Localizacao' },
    id_nivel_loc2_destino: { type: String, ref: 'Localizacao' },
    id_nivel_loc3_destino: { type: String, ref: 'Localizacao' },
    id_nivel_loc4_destino: { type: String, ref: 'Localizacao' },

    retorno_api:  { type: String },
    // caso tenha mais um processo, replica do registro com nivel_destino como origem

    logs_payload: [{
        data: { type: Date, default: Date.now },
        payload: { type: mongoose.Schema.Types.Mixed }
    }],

}, {
    versionKey: false,
    timestamps: true
});

// Índices para portal / atender-tag em bases grandes (ex.: 1M+)
PosicaoSchema.index({ id_conta: 1, 'itens.tag': 1 });
PosicaoSchema.index({ id_conta: 1, 'itens.tag': 1, 'itens.status': 1 });
PosicaoSchema.index({ id_conta: 1, tipo: 1, partida_data: 1, createdAt: -1 });
PosicaoSchema.index({ id_conta: 1, status: 1, createdAt: -1 });

module.exports = mongoose.model('Posicao', PosicaoSchema);
